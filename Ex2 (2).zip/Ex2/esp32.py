import base64
from flask import Flask, Blueprint, render_template,request
import requests
import conf
import time
from datetime import datetime
import paho.mqtt.client as mqtt

main = Blueprint('main', __name__, template_folder="templates")

MQTT_BROKER = 'localhost'  # Pode usar localhost ou outro broker
MQTT_PORT = 8883
TOPIC = 'image'

# Inicializar cliente MQTT
client = mqtt.Client()
#Esp32
def tirarFoto():
    with open('img/foto.jpg', 'rb') as image_file:
    # Codifique a imagem para base64
        encoded_image = base64.b64encode(image_file.read()).decode('utf-8')
        return encoded_image
    
def enviarFotoMQTT():
    client.connect(MQTT_BROKER, MQTT_PORT)
    dataImg = tirarFoto()
    data = f"{dataImg}:{time.time_ns()}"
    client.publish(TOPIC, data)
    client.disconnect()

def enviarFotoServidor(url):
    dataImg = tirarFoto()
    data = {
        'image'     : dataImg,
        'sendTime'  : time.time_ns()
    }

    resposta = requests.post(url, json=data, verify=False)
    print("Resposta Envio: ", resposta.status_code)
    

@main.route('/',methods=['POST', 'GET'])
@main.route('/esp',methods=['POST', 'GET'])
def esp():
    data = request.form
    msg=""
    if "cmd" in data.keys():
        if data["cmd"] == "TirarFoto":
            enviarFotoServidor(f"{conf.hostServidor}:{conf.portaServidor}/servidor")
            msg="Mensagem enviada as " + datetime.now().strftime("%H:%M:%S")
    return render_template(f'esp32.html', msg=msg, page="esp")

@main.route('/espMQTT',methods=['POST', 'GET'])
def espMQTT():
    data = request.form
    msg=""
    if "cmd" in data.keys():
        if data["cmd"] == "TirarFoto":
            enviarFotoMQTT()
            msg="Mensagem enviada as " + datetime.now().strftime("%H:%M:%S")
    return render_template(f'esp32.html', msg=msg, page="espMQTT")

def create_app():
    app = Flask(__name__)
    
    app.register_blueprint(main)
    
    return app

if __name__ == '__main__':
    
    app = create_app()
    
    if "https" in conf.hostEsp32:
        app.run(debug=True, port=conf.portaEsp32, ssl_context=('certificados/certificadoEsp.pem', 'certificados/chave_privadaEsp.pem'))
    else:
        app.run(debug=True, port=conf.portaEsp32)
    