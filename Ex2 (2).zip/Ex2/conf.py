hostServidor = "https://127.0.0.1"
portaServidor = 8082

hostEsp32 = "https://127.0.0.1"
portaEsp32 = 8081