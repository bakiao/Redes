import base64
from flask import Flask, Blueprint, render_template,request, redirect
import conf
import time
import paho.mqtt.client as mqtt
from datetime import datetime
import os

main = Blueprint('main', __name__, template_folder="templates") 

MQTT_BROKER = 'localhost'  # Pode usar localhost ou outro broker
MQTT_PORT = 8883
TOPIC = 'image'

# Inicializar cliente MQTT
client = mqtt.Client()

def receiveImage(client, userdata, msg):
    global contador
    if(msg.topic == TOPIC):
        data = str(msg.payload.decode())
        image_data, tempo = data.split(":")
        image_data = base64.b64decode(image_data)
        with open(f'static/servidor/fotoMQTT{contador}_{datetime.now().strftime("%H-%M-%S")}.jpg', 'wb') as image_file:
            image_file.write(image_data)
        
        print("Tempo da Solucao" ,time.time_ns() - int(tempo), "ns")
        
        contador+=1


#Servidor
contador = 0
@main.route('/',methods=['POST', 'GET'])
@main.route('/servidor',methods=['POST', 'GET'])


def servidor():
    
    if request.method == "POST":
        
        data = request.json
        global contador
        if "image" in data.keys():
            image_data = base64.b64decode(data["image"])
            with open(f'static/servidor/foto{contador}_{datetime.now().strftime("%H-%M-%S")}.jpg', 'wb') as image_file:
                image_file.write(image_data)
            contador+=1
            print("Tempo da Solucao" ,time.time_ns() - data["sendTime"], "ns")
        
    diretorio = os.getcwd() + "/static/servidor"
    fotos = os.listdir(diretorio)


    return render_template(f'servidor.html', fotos=fotos, cont=contador)


def create_app():
    app = Flask(__name__)
    
    app.register_blueprint(main)
    
    return app

if __name__ == '__main__':
    
    app = create_app()
    
    client.connect(MQTT_BROKER, MQTT_PORT)
    client.subscribe(TOPIC)
    client.on_message = receiveImage
    client.loop_start()
    if "https" in conf.hostServidor:
        app.run(debug=True, port=conf.portaServidor, ssl_context=('certificados/certificadoServ.pem', 'certificados/chave_privadaServ.pem'))
    else:
        app.run(debug=True, port=conf.portaServidor)